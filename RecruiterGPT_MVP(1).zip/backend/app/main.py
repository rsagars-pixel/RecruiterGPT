from fastapi import FastAPI

app = FastAPI(title="RecruiterGPT")

@app.get("/health")
def health():
    return {"status":"ok"}
