# RecruiterGPT MVP

FastAPI + PostgreSQL + OpenAI starter scaffold.
